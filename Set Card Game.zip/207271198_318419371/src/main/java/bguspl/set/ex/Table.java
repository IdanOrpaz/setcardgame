package bguspl.set.ex;
import bguspl.set.Env;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;


/**
 * This class contains the data that is visible to the player.
 *
 * @inv slotToCard[x] == y iff cardToSlot[y] == x
 */
public class Table {

    /**
     * The game environment object.
     */
    private final Env env;

    /**
     * Mapping between a slot and the card placed in it (null if none).
     */
    protected final Integer[] slotToCard; // card per slot (if any)

    /**
     * Mapping between a card and the slot it is in (null if none).
     */
    protected final Integer[] cardToSlot; // slot per card (if any)

    
    // FIELDS WE ADDED

    /**
     * Mapping between players and their tokens (Slots).
     */
    private Integer[][] playerTokens;

    /**
     * Set size should be the feature size:
     * https://moodle.bgu.ac.il/moodle/mod/forum/discuss.php?d=698081#p1056859
     * we initialize it in the cosnturctor to support FeatureSize property
     */
    public int MAX_TOKENS_ALLOWED;


    /**
     * Locker for slotToCard , cardToSlot , playerTokens group
     */
    private Object cardAndTokenLock;


    
     /**
     * Players set test requests - when reached to 3 tokens - Input objects are player ids.
     */
    protected BlockingQueue<Integer> testRequests;

     /**
     * Array that holds the result of the last set validation done by the dealer for each player.
     * 0 = false (Illegal set) , -1 = no request , 1 = true (Legal set)
     */
    protected Integer[] answers; 


    /**
     * useful constants for bonus 1
     */
    public static final Integer ILLEGAL_SET=0;
    public static final Integer EMPTY= -1; // no token \ no answer
    public static final Integer LEGAL_SET=1;
    


    /**
     * Constructor for testing.
     *
     * @param env        - the game environment objects.
     * @param slotToCard - mapping between a slot and the card placed in it (null if none).
     * @param cardToSlot - mapping between a card and the slot it is in (null if none).
     */
    public Table(Env env, Integer[] slotToCard, Integer[] cardToSlot) {

        this.env = env;
        this.slotToCard = slotToCard;
        this.cardToSlot = cardToSlot;
        this.MAX_TOKENS_ALLOWED = env.config.featureSize;

        // TOKENS placement
        this.playerTokens = new Integer[env.config.players][MAX_TOKENS_ALLOWED];
        for (Integer[] i : playerTokens){
            for (Integer j = 0 ; j< i.length ; j ++){
                i[j] = EMPTY;
            }
        }
        // set test requests
        this.testRequests = new LinkedBlockingQueue<>();

        // responses of the set test requests
        answers = new Integer[env.config.players];
        for (Integer j = 0 ; j < answers.length ; j ++){
            answers[j] = EMPTY;
        } 

        this.cardAndTokenLock = new Object();
    }

    /**
     * Constructor for actual usage.
     *
     * @param env - the game environment objects.
     */
    public Table(Env env) {
        this(env, new Integer[env.config.tableSize], new Integer[env.config.deckSize]);
    }

    /**
     * This method prints all possible legal sets of cards that are currently on the table.
     */
    public void hints() {
        synchronized (cardAndTokenLock) {
        List<Integer> deck = Arrays.stream(slotToCard).filter(Objects::nonNull).collect(Collectors.toList());
        env.util.findSets(deck, Integer.MAX_VALUE).forEach(set -> {
            StringBuilder sb = new StringBuilder().append("Hint: Set found: ");
            List<Integer> slots = Arrays.stream(set).mapToObj(card -> cardToSlot[card]).sorted().collect(Collectors.toList());
            int[][] features = env.util.cardsToFeatures(set);
            System.out.println(sb.append("slots: ").append(slots).append(" features: ").append(Arrays.deepToString(features)));
        });
        }
    }

    /**
     * Count the number of cards currently on the table.
     *
     * @return - the number of cards on the table.
     */
    public int countCards() {
        int cards = 0;
        for (Integer card : slotToCard)
            if (card != null)
                ++cards;
        return cards;
    }

    /**
     * Places a card on the table in a grid slot.
     * @pre - slot is empty
     * @param card - the card id to place in the slot.
     * @param slot - the slot in which the card should be placed.
     *
     * @post - the card placed is on the table, in the assigned slot.
     */
    // Validation should be done on the dealer side (TABLE IS PASSIVE OBJECT): is the slot empty? is the card available?
    public void placeCard(int card, int slot) {
        // TODO implement
        synchronized (cardAndTokenLock) {
            try {
                Thread.sleep(env.config.tableDelayMillis);
            } catch (InterruptedException ignored) {}
            cardToSlot[card] = slot;
            slotToCard[slot] = card;
            env.ui.placeCard(card, slot);                    // apply change on ui
        }
    }


    /**
     * Removes a card from a grid slot on the table.
     * @param slot - the slot from which to remove the card.
     */
    public void removeCard(int slot) {
        // TODO implement
        synchronized (cardAndTokenLock) {
            try {
                Thread.sleep(env.config.tableDelayMillis);
            } catch (InterruptedException ignored) {};

            cardToSlot[slotToCard[slot]] = null ; // card should now point to no slot
            slotToCard[slot] = null; 
    
            // "hand back tokens" to the player
            for (int player_id = 0 ; player_id < env.config.players ; player_id++) {
                removeToken(player_id, slot); 
                }
        }

        env.ui.removeCard(slot);    // apply change on ui
        env.ui.removeTokens(slot);
    }

    /**
     * Places a player token on a grid slot.
     * @param player - the player the token belongs to.
     * @param slot   - the slot on which to place the token.
     */
    public void placeToken(int player, int slot) {
        // TODO implement
        synchronized (cardAndTokenLock) {
            if (!isSlotEmpty(slot)){
                for (int i = 0 ; i < MAX_TOKENS_ALLOWED ; i++){
                    if (playerTokens[player][i] == EMPTY){
                        playerTokens[player][i] = slot;     // use the first available token
                        env.ui.placeToken(player, slot);    // apply change on ui
                        break;
                    }
                }
            }
        }
    }

    /**
     * Removes a token of a player from a grid slot.
     * @param player - the player the token belongs to.
     * @param slot   - the slot from which to remove the token.
     * @return       - true iff a token was successfully removed.
     */
    public boolean removeToken(int player, int slot) {
        // TODO implement
        synchronized (cardAndTokenLock) {
            for (int i = 0 ; i < MAX_TOKENS_ALLOWED ; i++) {
                if (playerTokens[player][i] == slot){
                    playerTokens[player][i] = EMPTY;
                    env.ui.removeToken(player, slot);
                    return true;
                }
            } 
            return false;     
        }
    }

    //--------------------Methods we created---------------------//


    /**
     * @return  true if slot is empty, false otherwise
     */
    public boolean isSlotEmpty(int slot) {
        synchronized(cardAndTokenLock){
            if (slotToCard[slot] == null) {
                return true;
            }
            return false;
        }
    }

    
    /**
     * @return  - 0-3 How many tokens this player has already on the table
     */
    public int countPlayerTokens(int player_id) {
        synchronized(cardAndTokenLock){
            int counter = 0;
            for (int i = 0 ; i < MAX_TOKENS_ALLOWED ; i++) {
                if (playerTokens[player_id][i] != EMPTY) {
                    counter++;
                }
            }
            return counter;
        }
    }

    /**
     * @return  true if any player has a token on slot, false otherwise
     */
    public boolean hasTokenOnSlot(int player_id, int slot) {
        synchronized(cardAndTokenLock){
            for (int i = 0 ; i < MAX_TOKENS_ALLOWED ; i++) {
                if (playerTokens[player_id][i] != EMPTY) {
                    if (playerTokens[player_id][i] == slot) {
                        return true;
                    }
                }
            }
            return false;
        }
    }

    /**
     * @return  array size 3 with the slots that the player has token on. Index without slot would be null.
     */
    public int[] getPlayerTokens(int player_id) {
        synchronized(cardAndTokenLock){
            int[] intArray = new int[MAX_TOKENS_ALLOWED];
            for (int i = 0; i < MAX_TOKENS_ALLOWED; i++) {
                intArray[i] = playerTokens[player_id][i];
            }
            return intArray;
        }
    }

    /**
     * @return  array size 3 with the cards that the player has tokens on. Index without card would be null.
     */
    public int[] getPlayerCards(int player_id){
        synchronized(cardAndTokenLock){
            int[] intArray = new int[MAX_TOKENS_ALLOWED];
            for (int i = 0; i < MAX_TOKENS_ALLOWED; i++) {
                intArray[i] = slotToCard[playerTokens[player_id][i]];
            }
            return intArray;
        }
    }

}
