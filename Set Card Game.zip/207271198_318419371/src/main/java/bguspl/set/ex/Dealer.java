package bguspl.set.ex;
import bguspl.set.Env;
// import bguspl.set.UtilImpl;
// import java.util.ArrayList;
import java.util.Collections;           // utility class we added for shuffle method
import java.util.List;
import java.util.concurrent.CountDownLatch; // bonus 2
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * This class manages the dealer's threads and data
 */
public class Dealer implements Runnable {

    /**
     * The game environment object.
     */
    private final Env env;

    /**
     * Game entities.
     */
    private final Table table;
    private final Player[] players;

    /**
     * The list of card ids that are left in the dealer's deck.
     */
    private final List<Integer> deck;

    /**
     * True iff game should be terminated.
     */
    private volatile boolean terminate;

    // fields we added 
    private boolean isSlotEmpty;
    private long timerWarningTime;
    public volatile boolean insertTokenAllowed;
    private Thread dealerThread;
    private boolean hints;

    /**
     * The time when the dealer needs to reshuffle the deck due to turn timeout.
     */
    private long reshuffleTime = Long.MAX_VALUE;
    

    /**
     * fields we added to configure the waiting time until next action under the time definition
     */
    private final int REGULAR_WAIT = 1000; 
    private final int WARNING_WAIT = 10; 

    private CountDownLatch startLatch; // bonus 2
    

    public Dealer(Env env, Table table, Player[] players) {
        this.env = env;
        this.table = table;
        this.players = players;
        deck = IntStream.range(0, env.config.deckSize).boxed().collect(Collectors.toList());
        isSlotEmpty = true;
        insertTokenAllowed = false;  
        hints = env.config.hints;
        this.startLatch = new CountDownLatch(1);
    }
    
    /**
     * The dealer thread starts here (main loop for the dealer thread).
     */
    @Override
    public void run() {
        env.logger.info("thread " + Thread.currentThread().getName() + " starting.");
        dealerThread = Thread.currentThread();

         // CODE WE ADDED
        startPlayersByOrder();
        //
        
        while (!shouldFinish()) {
            placeCardsOnTable();
            timerLoop();
            updateTimerDisplay(false);
            removeAllCardsFromTable();
        }

        announceWinners();

        if (!terminate) {   // in case game terminated naturally , make sure to terminate player threads
            terminate();
        }

        try {Thread.sleep(env.config.endGamePauseMillies);} // bonus 1 - pause before game ends
        catch (InterruptedException ignored) {}

        env.logger.info("thread " + Thread.currentThread().getName() + " terminated.");
    }

    /**
     * The inner loop of the dealer thread that runs as long as the countdown did not time out.
     */
    private void timerLoop() {
        while (!terminate && System.currentTimeMillis() < reshuffleTime) {
            sleepUntilWokenOrTimeout();
            updateTimerDisplay(false);
            removeCardsFromTable();
            placeCardsOnTable();
        }
    }

    /**
     * Called when the game should be terminated.
     */
    public void terminate() {
        // TODO implement 
        for (int i = players.length - 1 ; i>=0 ; i--) {
            players[i].terminate();
        }
        terminate = true;
        dealerThread.interrupt();
    }

    /**
     * Check if the game should be terminated or the game end conditions are met.
     *
     * @return true iff the game should be finished.
     */
    private boolean shouldFinish() {
        return terminate || env.util.findSets(deck, 1).size() == 0;
    }

    /**
     * Checks cards should be removed from the table and removes them.
     */
    private void removeCardsFromTable() {
        // TODO implement
        if (table.testRequests.isEmpty() == false) {

            int player_id = testSet();      // check if this player has a set. return the player tested
  
            if (table.answers[player_id] == Table.LEGAL_SET){             // if player has set
                int[] playerSlots = table.getPlayerTokens(player_id) ;
                for(int slot : playerSlots) {               // remove player cards
                    table.removeCard(slot);
                }
                isSlotEmpty = true;
            }

            synchronized(table.answers){
                table.answers.notifyAll() ;         //sign all player threads that were waiting for dealer for answer to continue.
            }

        }
        updateTimerDisplay(false);
    }
    
    /**
     * Check if any cards can be removed from the deck and placed on the table.
     */
    private void placeCardsOnTable() {
        // TODO implement   
        // if there are cards on the deck: go through every index in the slot: if it's null: insert the first card in the deck, delete it from the deck, update ui. 
        // at the end of every insertion of cards we should reset the timer.
        
        if (isSlotEmpty){               // when time has ended 
            Collections.shuffle(deck);
                for(int i = 0; i < env.config.tableSize && deck.size()>0 ; i++){
                    if (table.isSlotEmpty(i) == true){
                        int card_id = deck.get(0); // 0 = head of the deck
                        deck.remove(0);         // 0 = head of the deck , very heavy method, maybe we should take the last card
                        table.placeCard(card_id, i);  // insert the card from deck to slot. also logs the action and updates ui
                    }
                }
            isSlotEmpty = false;  
            insertTokenAllowed = true;             // players can start inserting tokens
            updateTimerDisplay(true);       //when finished inserting cards timer restarts.
            
            if (hints) { // bonus 1
                table.hints();
                System.out.println("@@@@@@@@@@@@@");
            }
        }
        
    }


    /**
     * Sleep for a fixed amount of time or until the thread is awakened for some purpose.
     */
    private void sleepUntilWokenOrTimeout() {
        // TODO implement
        synchronized (table.testRequests) {
            if (table.testRequests.isEmpty()) { 
                if (timerWarningTime < System.currentTimeMillis()){
                    try {
                        table.testRequests.wait(WARNING_WAIT);
                    }
                    catch (InterruptedException e) {}       
                }
                        
                else{
                    try{
                        table.testRequests.wait(REGULAR_WAIT);
                    }

                    catch (InterruptedException e) {}

                    }
            }                 
        } 
    }


    /**
     * Reset and/or update the countdown and the countdown display.
     */
    private void updateTimerDisplay(boolean reset) {
        // TODO implement  
        if (reset){                                                                 // when reset needs to be done
            reshuffleTime = System.currentTimeMillis() + env.config.turnTimeoutMillis;
            timerWarningTime = reshuffleTime - env.config.turnTimeoutWarningMillis;
            env.ui.setCountdown(reshuffleTime - System.currentTimeMillis(), false);
        }
        else {                                                                      // if no reset is needed
            if (System.currentTimeMillis() > timerWarningTime){                     // if we reached warning alert time
                if (System.currentTimeMillis() > reshuffleTime){           // if very close to time limit 
                    env.ui.setCountdown(0,true);}
                else{
                    env.ui.setCountdown(reshuffleTime - System.currentTimeMillis(), true);}
            }
            else {                                                                   // if theres time until warning
                env.ui.setCountdown(reshuffleTime - System.currentTimeMillis(), false); 
            }
        }
    }

    /**
     * Returns all the cards from the table to the deck.
     */
    private void removeAllCardsFromTable() {
        // TODO implement
        synchronized(table){
            insertTokenAllowed = false;   
            for (int i = 0; i < env.config.tableSize ; i++) {
                if (table.isSlotEmpty(i) == false) {
                    int card_id = table.slotToCard[i];
                    deck.add(card_id); // return card from table to deck
                    table.removeCard(i); // update slotToCard + UI + log
                }
            }
        }
        isSlotEmpty = true;
    }


    /**
     * Check who is/are the winner/s and displays them.
     */
    private void announceWinners() {
        // TODO implement

        // Count the winners
        int max_score = 0;
        int winner_counter = 0;
        for (int i = 0; i < players.length ; i++) {
            int player_score = players[i].score();
            if (player_score == max_score) {
                winner_counter++;
            }
            else if (player_score > max_score) {
                max_score = player_score;
                winner_counter = 1; // winner with new score
            }
        }

        // Store the winners
        int[] winners = new int[winner_counter];
        int j = 0;
        for (int i = 0; i < players.length ; i++) {
            if (players[i].score() == max_score) {
                winners[j] = players[i].id;
                j = j+1;
            }
        }
        env.ui.announceWinner(winners);
    }


    // Method we added
    public int testSet() {
        boolean isSet;
        int player_id;
            try{
                player_id = table.testRequests.take();
                // Edge case - card was removed in prior testSet request - automatically go for ILLEGAL SET
                if (table.countPlayerTokens(player_id) < table.MAX_TOKENS_ALLOWED) {
                    table.answers[player_id] = table.ILLEGAL_SET;
                    return player_id;
                }

                // otherwise test the set and reply the answer
                int[] cards = table.getPlayerCards(player_id);
                isSet = env.util.testSet(cards); 
                table.answers[player_id] = isSet ? Table.LEGAL_SET : table.ILLEGAL_SET;
                return player_id;
            
            }
            catch(InterruptedException e){};
        return Table.EMPTY;
    }


    /**
     * ensure player threads start by the order of their creation,
     * Using CountDownLatch as a messanger indicating the current player
     * has indeed started and we can continue to the next one
     */

    private void startPlayersByOrder() {
        for (Player player : players) {
            player.setStartLach(this.startLatch);
            Thread playerThread = new Thread(player);
            playerThread.start();
            try {startLatch.await();}
            catch (InterruptedException ignored) {}
            startLatch = new CountDownLatch(1);  
        }
    }
}
